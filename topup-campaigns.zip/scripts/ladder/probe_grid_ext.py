#!/usr/bin/env python3
"""Extended probe grid: the same probes, classifier and trial design as
probe_grid.py, on additional workload states (smaller reply delays and
heavier reply loss). It reuses probe_grid.py unchanged and only replaces
its list of states, so the two grids are directly comparable.

States: delay500, delay1000, delay1500 (reply delay), loss70, loss90
(reply loss); all are reachable workloads. Same arguments as probe_grid.py.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import probe_grid as pg  # noqa: E402

pg.STATES = {
    "delay500": "delay 500ms",
    "delay1000": "delay 1000ms",
    "delay1500": "delay 1500ms",
    "loss70": "loss 70%",
    "loss90": "loss 90%",
}
pg.GROUND_TRUTH = {s: "reachable" for s in pg.STATES}

if __name__ == "__main__":
    pg.main()
